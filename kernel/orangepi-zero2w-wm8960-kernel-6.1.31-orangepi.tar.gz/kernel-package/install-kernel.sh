#!/bin/bash
set -e

if [ "$EUID" -ne 0 ]; then 
    echo "ERROR: Must run as root"
    exit 1
fi

VERSION="6.1.31-orangepi"

echo "Installing Orange Pi kernel with WM8960 support..."
echo "Version: $VERSION"
echo ""

# Backup existing kernel
echo "Backing up existing kernel..."
cp /boot/vmlinuz-${VERSION} /boot/vmlinuz-${VERSION}.backup 2>/dev/null || true

# Install kernel files
echo "Installing kernel..."
cp vmlinuz-${VERSION} /boot/
cp System.map-${VERSION} /boot/
cp config-${VERSION} /boot/

# Install modules
echo "Installing modules..."
cp -r modules/sound /lib/modules/${VERSION}/kernel/ || true
cp modules/modules.* /lib/modules/${VERSION}/ || true

# Update module dependencies
echo "Updating module dependencies..."
depmod -a ${VERSION}

echo ""
echo "Kernel installation complete!"
echo "The WM8960 codec module is now available."
echo ""
echo "Next steps:"
echo "1. Install the WM8960 driver package"
echo "2. Reboot: sudo reboot"
