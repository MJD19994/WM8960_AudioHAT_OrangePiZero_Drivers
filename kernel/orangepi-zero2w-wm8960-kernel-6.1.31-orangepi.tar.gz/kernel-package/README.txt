Orange Pi Zero 2W Kernel with WM8960 Support
Version: 6.1.31-orangepi

This package contains a pre-compiled kernel with WM8960 audio codec support
for Orange Pi Zero 2W (H618).

INSTALLATION:
1. Extract this archive
2. Run: sudo ./install-kernel.sh
3. Install WM8960 driver package from main repository
4. Reboot

WHAT'S INCLUDED:
- Kernel image (vmlinuz-6.1.31-orangepi)
- System map and config
- WM8960 codec kernel module
- Sound subsystem modules

COMPATIBILITY:
- Orange Pi Zero 2W (H618)
- Orange Pi OS 1.0.2 Bookworm

For support, see: https://github.com/YOUR_USERNAME/WM8960_AudioHAT_OrangePiZero_Drivers
